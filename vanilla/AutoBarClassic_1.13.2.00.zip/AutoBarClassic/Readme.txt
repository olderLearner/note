All releases will be done on Curse.com and WoWInterface.com so grab it from wherever you prefer.

Main support site:
https://muffinmangames.com


*For Cooldown counts please use Omni Cooldown Count
*For skinning install the Masque addon

Changes:
v1.13.2.00:
 - Initial Release for Classic
 - NOTE: LOTS of items/spells are missing but there shouldn`t be any lua errors
