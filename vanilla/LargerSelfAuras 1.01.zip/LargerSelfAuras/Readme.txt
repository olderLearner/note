LargerSelfAuras
Created by Novaspark-Firemaw EU

Classic only.
This addon will show your own buffs/debuffs larger on the target frame like retail.
You can change the size of your own and others auras in options with the /lsa command.